package com.example.tabnavigation;

public class ItemData {
    public String itemTitle;
    public String itemSubTitle;
}
